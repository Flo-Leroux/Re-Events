
import { ImagePicker } from '@ionic-native/image-picker';
import { Inject } from '@angular/core';

export class Permissions {
    
    constructor(@Inject(ImagePicker) public imgPicker: ImagePicker) {}

    imagePicker(): void {
        this.imgPicker.hasReadPermission()
        .then(res => {
            if(!res) {
                this.imgPicker.requestReadPermission();
            }
        })
    }
}