export interface User {
    email: string;
    password: string;
    nom: string;
    prenom: string;
    birthday: Date;
}