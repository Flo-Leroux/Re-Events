import { Injectable } from '@angular/core';

import { ImagePicker } from '@ionic-native/image-picker';
/*
  Generated class for the TestProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class TestProvider {

  constructor(private img: ImagePicker) {
    console.log('Hello TestProvider Provider');
  }

}
