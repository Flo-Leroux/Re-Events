
import { Injectable } from '@angular/core';

// --- Add Plugins --- //
/* Add Ionic's Plugins */
import { ImagePicker } from '@ionic-native/image-picker';

@Injectable()
export class PermissionsProvider {

  constructor(public imgPicker: ImagePicker) { }

  /**
   * Test si l'application a le droit d'accerder aux images de l'appareil
   *    - Si False => Fait une demande
   * @returns {void} Rien
   */
  imagePicker(): void {
    this.imgPicker.hasReadPermission().then(res => {
      if(!res) {
        this.imgPicker.requestReadPermission();
      }
    })
  }

}
