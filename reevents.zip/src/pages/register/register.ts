import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

// --- Add Plugins --- //
/* Ionic's Plugins */
import { StatusBar } from '@ionic-native/status-bar';
import { NativePageTransitions, NativeTransitionOptions } from '@ionic-native/native-page-transitions';

// --- Add Models --- //
import { User } from '../../models/User';

// --- Add Pages --- //
import { RegisterphotoPage } from '../registerphoto/registerphoto';

// --- Add Providers --- //
import { RegexProvider } from '../../providers/regex/regex';

@Component({
  selector: 'page-register',
  templateUrl: 'register.html'
})
export class RegisterPage {

  user = {} as User;

  email: boolean = false;
  step1: boolean = true;
  step2: boolean = false;

  confirmation: string = "";

  constructor(public navCtrl: NavController,
              private statusBar: StatusBar,
              private nativePageTransitions: NativePageTransitions,
              private reg: RegexProvider) {
    this.ionView();
  }

  ionView() {
    // let status bar overlay webview
    this.statusBar.overlaysWebView(true);
    
    // set status bar to white
    /* this.statusBar.backgroundColorByHexString('#B3000000'); */
    this.statusBar.styleDefault();
  }

  /**
   * Test si l'email est valide :
   *    - True  =>  Affiche les champs "Mot de passe" & "Confirmation"
   *    - False =>  Affiche un message d'erreur
   * @param {User} user 
   */
  emailInput(user: User) {
    let regEmail: boolean = this.reg.email(user.email);

    if(regEmail) {
      this.email = true;
    }
    else {
      this.email = false;
    }
  }

  /**
   * Test si le mot de passe et la confirmation sont égaux et valides :
   *    - True  =>  Affiche les champs "Nom", "Prénom" & "Date de naissance"
   *    - False =>  Affiche un message d'erreur
   * @param {User} user 
   */
  passwordConfirm(user: User) {
    let regPassword: boolean = this.reg.password(user.password);
    let regConfirm: boolean = this.reg.password(this.confirmation);

    if(regPassword && regConfirm && user.password.length>=8 && this.confirmation.length>=8) {
      if(user.password === this.confirmation) {
        this.step1 = false;
      }
    }
    else {
      this.step1 = true;
    }
  }

  /**
   * Test si les champs "Nom" & "Prénom" sont complétés :
   *    - True  =>  Active le bouton "S'inscrire"
   *    - False =>  Affiche un message d'erreur
   * @param {User} user 
   */
  step2Inputs(user: User) {
    if(user.nom && user.prenom) {
      this.step2 = true;
    }
    else {
      this.step2 = false;
    }
  }

  register() {
    let options: NativeTransitionOptions = {
      duration: 800,
      slowdownfactor: -1,
      iosdelay: 50,
      androiddelay: 100,
    }; 
    this.nativePageTransitions.fade(options);
    this.navCtrl.setRoot(RegisterphotoPage);
  }

}
