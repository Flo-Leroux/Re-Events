import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

// --- Add Plugins --- //
/* Ionic's Plugins */
import { StatusBar } from '@ionic-native/status-bar';
import { NativePageTransitions, NativeTransitionOptions } from '@ionic-native/native-page-transitions';

// --- Add Pages --- //
import { RegisterPage } from '../register/register';

import { TestProvider } from '../../providers/test/test';

@Component({
  selector: 'page-login',
  templateUrl: 'login.html'
})
export class LoginPage {

  constructor(public navCtrl: NavController,
              private statusBar: StatusBar,
              private nativePageTransitions: NativePageTransitions,
              private test: TestProvider) {
    this.ionView();
  }

  ionViewWillLeave() {

  }

  ionView() {
    // let status bar overlay webview
    this.statusBar.overlaysWebView(true);
    
    // set status bar to white
    /* this.statusBar.backgroundColorByHexString('#B3000000');
    this.statusBar.styleLightContent(); */
  }

  register() {
    let options: NativeTransitionOptions = {
      duration: 500,
      slowdownfactor: -1,
      iosdelay: 50,
      androiddelay: 100,
    }; 
    this.nativePageTransitions.fade(options);
    this.navCtrl.setRoot(RegisterPage);
  }

}
