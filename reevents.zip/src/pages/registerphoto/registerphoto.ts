import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

// --- Add Plugins --- //
/* Ionic's Plugins */
import { StatusBar } from '@ionic-native/status-bar';
import { ImagePicker } from '@ionic-native/image-picker';

// --- Add Models --- //
import { User } from '../../models/User';

// --- Add Pages --- //

// --- Add Providers --- //
import { PermissionsProvider } from '../../providers/permissions/permissions';

@Component({
  selector: 'page-registerphoto',
  templateUrl: 'registerphoto.html'
})
export class RegisterphotoPage {

  user = {} as User;
  imgPath: any = "assets/imgs/persona.jpg";

  constructor(public navCtrl: NavController,
              private statusBar: StatusBar,
              private imagePicker: ImagePicker,
              private permissions: PermissionsProvider) { }

  ionViewWillEnter() {
    // let status bar overlay webview
    this.statusBar.overlaysWebView(true);
    
    // set status bar to white
    // this.statusBar.backgroundColorByHexString('#B3000000');
    this.statusBar.styleDefault();
  }

  ionViewDidEnter() {
    this.permissions.imagePicker();        
  }

  selectImage() {
    this.imgPath = "assets/imgs/persona.jpg";

    console.log("Select Image");    
    this.imagePicker.getPictures({
      maximumImagesCount: 1
    })
    .then(res => {
      if(res.length==0) {
        this.imgPath = "assets/imgs/persona.jpg";
      }
      else {
        this.imgPath = res;
      }
    })
    .catch(err => {
      this.imgPath = "assets/imgs/persona.jpg"; 
    })
  }
}
