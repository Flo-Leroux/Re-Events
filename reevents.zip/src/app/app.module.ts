import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';

// --- Add Plugins -- //
/* Ionic's Plugins */
import { SplashScreen } from '@ionic-native/splash-screen';
import { StatusBar } from '@ionic-native/status-bar';
import { NativePageTransitions } from '@ionic-native/native-page-transitions';
import { Keyboard } from '@ionic-native/keyboard';
import { ImagePicker } from '@ionic-native/image-picker';

// --- Add Pages --- //
import { ReEvents } from './app.component';
import { LoginPage } from '../pages/login/login';
import { RegisterPage } from '../pages/register/register';
import { RegisterphotoPage } from '../pages/registerphoto/registerphoto';

// --- Add Others Class --- //
import { RegexProvider } from '../providers/regex/regex';
import { PermissionsProvider } from '../providers/permissions/permissions';
import { TestProvider } from '../providers/test/test';

@NgModule({
  declarations: [
    ReEvents,
    LoginPage,
    RegisterPage,
    RegisterphotoPage
  ],
  imports: [
    BrowserModule,
    IonicModule.forRoot(ReEvents, {
      scrollAssist: true,
      autoFocusAssist: true 
    })
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    ReEvents,
    LoginPage,
    RegisterPage,
    RegisterphotoPage
  ],
  providers: [
    StatusBar,
    SplashScreen,
    Keyboard,
    ImagePicker,
    NativePageTransitions,
    {provide: ErrorHandler, useClass: IonicErrorHandler},
    RegexProvider,
    PermissionsProvider,
    TestProvider
  ]
})
export class AppModule {}
